package com.example.demo;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UserController {
    private List<User> users = new ArrayList<>();
    @GetMapping("/register")
    public String showRegisterForm() {
        return "register";
    }

    @PostMapping("/register")
    public String register(String username, String password, String confirmPassword, String email, Model model) {
        // Validation
        if(username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || email.isEmpty()) {
            model.addAttribute("errorMessage", "All fields are required.");
            return "register";
        }
        if(!password.equals(confirmPassword)) {
            model.addAttribute("errorMessage", "Passwords do not match.");
            return "register";
        }
        if(users.stream().anyMatch(user -> user.getUsername().equals(username))) {
            model.addAttribute("errorMessage", "Username already exists.");
            return "register";
        }
        
        // Store new user
        users.add(new User(username, password, email));
        model.addAttribute("message", "Registration successful. Please log in.");
        return "login";
    }

    @PostMapping("/login")
    public String login(String username, String password, HttpSession session, Model model) {
        // Validate login
        User user = users.stream()
                .filter(u -> u.getUsername().equals(username) && u.getPassword().equals(password))
                .findFirst()
                .orElse(null);

        if(user == null) {
            model.addAttribute("errorMessage", "Invalid username or password.");
            return "login";
        }

        // Create session
        session.setAttribute("loggedUser", user);
        return "welcome";
    }
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "login";
    }
}

